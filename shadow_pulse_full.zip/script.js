// Shadow Pulse — Full script.js
'use strict';

// Canvas and scaling
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H, DPR=window.devicePixelRatio||1;
function resize(){
  canvas.width = canvas.clientWidth * DPR;
  canvas.height = canvas.clientHeight * DPR;
  ctx.setTransform(DPR,0,0,DPR,0,0);
  W = canvas.clientWidth; H = canvas.clientHeight;
}
window.addEventListener('resize', resize);
resize();

// DOM
const overlay = document.getElementById('overlay');
const btnStart = document.getElementById('btnStart');
const btnReset = document.getElementById('btnReset');
const btnPause = document.getElementById('btnPause');
const waveEl = document.getElementById('wave');
const scoreEl = document.getElementById('score');
const hpEl = document.getElementById('hp');
const highscoreEl = document.getElementById('highscore');
const upgradesChosenEl = document.getElementById('upgradesChosen');
const upgradeChoicesEl = document.getElementById('upgradeChoices');

// Mobile controls
const hudMobile = document.getElementById('hudMobile');
const isMobile = /Mobi|Android/i.test(navigator.userAgent);
if(isMobile) hudMobile.classList.remove('hidden');

// Game state
let running=false, lastTime=0, score=0, wave=0;
let player, bullets=[], enemies=[], upgradeTimer=30, chosenUpgrades=[];
let keys = {}, mouse={x:0,y:0,down:false};
let highscore = Number(localStorage.getItem('sp_highscore')||0);
highscoreEl.textContent = highscore;

// Audio: simple WebAudio SFX generator (no external files)
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx=null;
function ensureAudio(){ if(!audioCtx){ audioCtx = new AudioCtx(); } }
function playClick(freq=800, duration=0.05, type='sine'){ try{ ensureAudio(); const o = audioCtx.createOscillator(); const g = audioCtx.createGain(); o.type = type; o.frequency.value = freq; g.gain.value = 0.02; o.connect(g); g.connect(audioCtx.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime+duration); o.stop(audioCtx.currentTime+duration); }catch(e){ } }

// Utilities
const rand = (min,max) => Math.random()*(max-min)+min;
const dist = (a,b) => { const dx=a.x-b.x, dy=a.y-b.y; return Math.hypot(dx,dy); };

function createPlayer(){
  return { x: W/2, y: H/2, r:14, speed:160, hp:100, maxHp:100, dmg:12, fireDelay:0.16, fireTimer:0, rollCooldown:0, rollTime:0, shadow:false };
}

const enemyTemplates = [
  {name:'Grunt',hp:18,spd:70,dmg:8,score:10},
  {name:'Stalker',hp:30,spd:60,dmg:14,score:20},
  {name:'Brute',hp:60,spd:40,dmg:22,score:50},
  {name:'Ranger',hp:24,spd:80,dmg:10,score:18,range:true}
];

function spawnWave(w){
  const count = Math.min(6 + Math.floor(w*1.6), 60);
  for(let i=0;i<count;i++){
    const t = enemyTemplates[Math.floor(rand(0,enemyTemplates.length))];
    const side = Math.floor(rand(0,4));
    const margin = 80;
    const x = W/2 + (side===0? -1: side===1? 1: 0)*(W*0.6) + rand(-100,100);
    const y = H/2 + (side===2? -1: side===3? 1: 0)*(H*0.6) + rand(-100,100);
    enemies.push({ x,y,vx:0,vy:0,r:12, hp:t.hp, maxHp:t.hp, spd:t.spd, dmg:t.dmg, score:t.score, type:t.name, mode:['aggr','def','ambush'][Math.floor(rand(0,3))], timer:rand(0,2) });
  }
}

function init(){
  score=0; wave=0; bullets=[]; enemies=[]; chosenUpgrades=[]; upgradeTimer=10;
  player = createPlayer();
  running=false;
  updateUI();
  showOverlay('آماده! روی شروع کلیک کن.');
}
init();

function startGame(){
  if(!running){ running=true; overlay.classList.add('hidden'); lastTime = performance.now(); upgradeTimer = 30; if(audioCtx && audioCtx.state==='suspended') audioCtx.resume(); spawnNext(); requestAnimationFrame(loop); playClick(900,0.06); }
}
function pauseGame(){ running=false; overlay.classList.remove('hidden'); overlay.innerText='متوقف شد'; }
function resetGame(){ init(); startGame(); }

function spawnNext(){ wave++; spawnWave(wave); updateUI(); }

function loop(t){
  if(!running) return;
  const dt = Math.min(0.05,(t-lastTime)/1000);
  update(dt); render();
  lastTime = t;
  requestAnimationFrame(loop);
}

function update(dt){
  if(player.rollTime>0){ player.rollTime=Math.max(0,player.rollTime-dt); if(player.rollTime===0) player.shadow=false; }
  if(player.rollCooldown>0) player.rollCooldown=Math.max(0,player.rollCooldown-dt);
  player.fireTimer = Math.max(0,player.fireTimer-dt);
  upgradeTimer = Math.max(0,upgradeTimer-dt);
  document.getElementById('hp').innerText = Math.floor(player.hp);

  // movement
  let vx=0, vy=0;
  if(keys['w']||keys['arrowup']) vy-=1;
  if(keys['s']||keys['arrowdown']) vy+=1;
  if(keys['a']||keys['arrowleft']) vx-=1;
  if(keys['d']||keys['arrowright']) vx+=1;
  const mag = Math.hypot(vx,vy) || 1;
  player.x += (vx/mag) * player.speed * dt;
  player.y += (vy/mag) * player.speed * dt;
  player.x = Math.max(20, Math.min(canvas.clientWidth-20, player.x));
  player.y = Math.max(20, Math.min(canvas.clientHeight-20, player.y));

  // roll
  if((keys[' ']||keys['shift']) && player.rollCooldown===0){
    player.rollTime = 0.28; player.rollCooldown=2.5; player.shadow=true; playClick(1200,0.06);
    if(chosenUpgrades.includes('shock')){
      enemies.forEach(e=>{ if(dist(e,player)<80){ e.hp -= 12; if(e.hp<=0) killEnemy(e); } });
    }
  }

  // shooting
  if(mouse.down && player.fireTimer===0){
    shootBullet(); player.fireTimer = player.fireDelay * (chosenUpgrades.includes('firerate')?0.78:1);
  }

  // bullets
  for(let i=bullets.length-1;i>=0;i--){
    const b = bullets[i];
    b.x += b.vx*dt; b.y += b.vy*dt; b.life -= dt;
    if(chosenUpgrades.includes('bounce')){
      if(b.x<0||b.x>canvas.clientWidth) b.vx *= -1;
      if(b.y<0||b.y>canvas.clientHeight) b.vy *= -1;
    }
    for(let j=enemies.length-1;j>=0;j--){
      const e = enemies[j];
      if(dist(b,e) < e.r + 4){
        e.hp -= b.dmg; b.life = 0; if(e.hp<=0) killEnemy(e); break;
      }
    }
    if(b.life<=0) bullets.splice(i,1);
  }

  // enemies AI
  enemies.forEach(e=>{
    e.timer -= dt;
    if(e.mode==='aggr'){
      const ang = Math.atan2(player.y - e.y, player.x - e.x);
      e.vx = Math.cos(ang)*e.spd; e.vy = Math.sin(ang)*e.spd;
    } else if(e.mode==='def'){
      const d = dist(e,player);
      if(d<140){ const ang = Math.atan2(e.y - player.y, e.x - player.x); e.vx = Math.cos(ang)*e.spd; e.vy = Math.sin(ang)*e.spd; }
      else { const ang = Math.atan2(player.y - e.y, player.x - e.x); e.vx = Math.cos(ang)*(e.spd*0.7); e.vy = Math.sin(ang)*(e.spd*0.7); }
      if(e.timer<=0){ e.mode = ['aggr','def','ambush'][Math.floor(rand(0,3))]; e.timer = rand(1,3); }
    } else {
      if(e.timer>0){ e.vx=0; e.vy=0; } else { const ang = Math.atan2(player.y - e.y, player.x - e.x); e.vx = Math.cos(ang)*e.spd*1.6; e.vy = Math.sin(ang)*e.spd*1.6; }
      if(e.timer<=-1.2){ e.timer = rand(0.5,2); e.mode = ['aggr','def'][Math.floor(rand(0,2))]; }
    }
    e.x += e.vx*dt; e.y += e.vy*dt;
    if(dist(e,player) < e.r + player.r + 6 && e.timer<=0){ if(player.rollTime<=0){ player.hp -= e.dmg * dt * 0.7; } }
  });

  // spawn next wave
  if(enemies.length===0){ spawnNext(); }

  // upgrade timer
  if(upgradeTimer<=0){ presentUpgrades(); upgradeTimer = 30; }

  if(player.hp<=0){ gameOver(); }
  updateUI();
}

function shootBullet(){
  const rect = canvas.getBoundingClientRect();
  const angle = Math.atan2(mouse.y - player.y, mouse.x - player.x);
  const speed = 520;
  bullets.push({ x:player.x, y:player.y, vx:Math.cos(angle)*speed, vy:Math.sin(angle)*speed, life:1.6, dmg: player.dmg * (chosenUpgrades.includes('dmg')?1.2:1) });
  playClick(1400,0.03,'square');
}

function killEnemy(e){
  score += e.score;
  if(Math.random()<0.08){ player.hp = Math.min(player.maxHp, player.hp + 12); playClick(600,0.04); }
  const idx = enemies.indexOf(e); if(idx>=0) enemies.splice(idx,1);
}

function presentUpgrades(){
  running=false;
  overlay.classList.remove('hidden');
  overlay.innerHTML = '<div style="font-weight:700;margin-bottom:6px">انتخاب آپگرید</div>';
  const choices = [];
  const pool = [
    {id:'spd',name:'سرعت +20%',desc:'حرکت سریع‌تر'},
    {id:'dmg',name:'آسیب +20%',desc:'گلوله‌ها قوی‌تر'},
    {id:'firerate',name:'نرخ شلیک +20%',desc:'کمتر تاخیر بین تیرها'},
    {id:'hpmax',name:'سلامت +30',desc:'حداکثر سلامت بیشتر'},
    {id:'bounce',name:'گلوله بازتابی',desc:'گلوله‌ها از دیوار می‌پرند'},
    {id:'shock',name:'موج شوک هنگام رول',desc:'رول به دشمنان صدمه می‌زند'}
  ];
  while(choices.length<3){
    const c = pool[Math.floor(rand(0,pool.length))];
    if(!choices.find(x=>x.id===c.id)) choices.push(c);
  }
  choices.forEach(ch=>{
    const b = document.createElement('div'); b.className='choice'; b.style.padding='8px'; b.style.margin='6px'; b.style.border='1px solid rgba(255,255,255,0.04)'; b.style.borderRadius='8px'; b.style.cursor='pointer';
    b.innerHTML = '<div style="font-weight:700;color:var(--white)">'+ch.name+'</div><div style="font-size:13px;color:var(--muted)">'+ch.desc+'</div>';
    b.onclick = ()=>{ chosenUpgrades.push(ch.id); applyUpgrade(ch.id); overlay.classList.add('hidden'); running=true; lastTime = performance.now(); playClick(1000,0.06); };
    overlay.appendChild(b);
  });
}

function applyUpgrade(id){
  if(id==='spd'){ player.speed *= 1.2; }
  if(id==='dmg'){ player.dmg *= 1.2; }
  if(id==='firerate'){ player.fireDelay *= 0.82; }
  if(id==='hpmax'){ player.maxHp += 30; player.hp += 30; }
  // bounce & shock handled in code paths
  updateUI();
}

function updateUI(){
  waveEl.innerText = 'Wave '+wave;
  scoreEl.innerText = Math.floor(score);
  upgradesChosenEl.innerText = chosenUpgrades.length? chosenUpgrades.join(', '): 'هیچ';
  document.getElementById('hp').innerText = Math.floor(player.hp);
  // highscore
  if(score>highscore){ highscore = Math.floor(score); localStorage.setItem('sp_highscore', highscore); highscoreEl.textContent = highscore; }
}

// render
function render(){
  ctx.clearRect(0,0,canvas.clientWidth,canvas.clientHeight);
  // grid
  ctx.save();
  ctx.globalAlpha = 0.04;
  ctx.fillStyle = '#ffffff';
  for(let x=0;x<canvas.clientWidth;x+=48) ctx.fillRect(x,0,1,canvas.clientHeight);
  for(let y=0;y<canvas.clientHeight;y+=48) ctx.fillRect(0,y,canvas.clientWidth,1);
  ctx.restore();

  // bullets
  bullets.forEach(b=>{ ctx.beginPath(); ctx.fillStyle='rgba(255,220,120,0.95)'; ctx.arc(b.x,b.y,4,0,Math.PI*2); ctx.fill(); });

  // player
  ctx.save(); ctx.translate(player.x,player.y);
  if(player.shadow) ctx.globalAlpha=0.5;
  ctx.beginPath(); ctx.fillStyle='#76d1ff'; ctx.arc(0,0,player.r,0,Math.PI*2); ctx.fill();
  // gun
  const ang = Math.atan2(mouse.y - player.y, mouse.x - player.x);
  ctx.rotate(ang); ctx.fillStyle='#0b1220'; ctx.fillRect(player.r-4, -6, 16,12);
  ctx.restore();

  // enemies
  enemies.forEach(e=>{
    ctx.beginPath();
    const color = e.mode==='aggr'?'#ff7575': e.mode==='def'?'#ffd77a':'#b39bff';
    ctx.fillStyle = color; ctx.arc(e.x,e.y,e.r,0,Math.PI*2); ctx.fill();
    // hp bar
    ctx.fillStyle='rgba(0,0,0,0.5)'; ctx.fillRect(e.x-14,e.y-e.r-8,28,4);
    ctx.fillStyle='rgba(0,200,120,0.9)'; ctx.fillRect(e.x-14,e.y-e.r-8,28*(e.hp/e.maxHp),4);
  });

  // crosshair
  ctx.beginPath(); ctx.strokeStyle='rgba(255,255,255,0.25)'; ctx.moveTo(mouse.x-8,mouse.y); ctx.lineTo(mouse.x+8,mouse.y); ctx.moveTo(mouse.x,mouse.y-8); ctx.lineTo(mouse.x,mouse.y+8); ctx.stroke();

  // player hp bar top-left
  ctx.fillStyle='rgba(0,0,0,0.5)'; ctx.fillRect(12,12,160,12);
  ctx.fillStyle='rgba(255,90,120,0.95)'; ctx.fillRect(12,12,160*(player.hp/player.maxHp),12);
  ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.strokeRect(12,12,160,12);
}

function gameOver(){
  running=false; overlay.classList.remove('hidden');
  overlay.innerHTML = '<div style="font-weight:800;font-size:18px;color:var(--accent);text-align:center">Game Over</div><div style="text-align:center;margin-top:8px">'+Math.floor(score)+' امتیاز</div><div style="margin-top:10px"><button id="playAgainBtn">بازی دوباره</button></div>';
  document.getElementById('playAgainBtn').onclick = ()=>{ init(); startGame(); };
  playClick(200,0.2,'sine');
}

// Input handling
window.addEventListener('keydown', e=>{ keys[e.key.toLowerCase()]=true; if(e.key===' '||e.key==='Shift') e.preventDefault(); });
window.addEventListener('keyup', e=>{ keys[e.key.toLowerCase()]=false; });
canvas.addEventListener('mousemove', e=>{ const rect = canvas.getBoundingClientRect(); mouse.x = (e.clientX - rect.left); mouse.y = (e.clientY - rect.top); });
canvas.addEventListener('mousedown', e=>{ mouse.down=true; });
canvas.addEventListener('mouseup', e=>{ mouse.down=false; });
canvas.addEventListener('touchstart', e=>{ e.preventDefault(); mouse.down=true; const t=e.touches[0]; const rect=canvas.getBoundingClientRect(); mouse.x=t.clientX-rect.left; mouse.y=t.clientY-rect.top; });
canvas.addEventListener('touchmove', e=>{ e.preventDefault(); const t=e.touches[0]; const rect=canvas.getBoundingClientRect(); mouse.x=t.clientX-rect.left; mouse.y=t.clientY-rect.top; });
canvas.addEventListener('touchend', e=>{ e.preventDefault(); mouse.down=false; });

// Mobile HUD buttons (basic)
document.getElementById('btnLeft').addEventListener('touchstart',()=>keys['a']=true); document.getElementById('btnLeft').addEventListener('touchend',()=>keys['a']=false);
document.getElementById('btnRight').addEventListener('touchstart',()=>keys['d']=true); document.getElementById('btnRight').addEventListener('touchend',()=>keys['d']=false);
document.getElementById('btnUp').addEventListener('touchstart',()=>keys['w']=true); document.getElementById('btnUp').addEventListener('touchend',()=>keys['w']=false);
document.getElementById('btnDown').addEventListener('touchstart',()=>keys['s']=true); document.getElementById('btnDown').addEventListener('touchend',()=>keys['s']=false);
document.getElementById('btnFire').addEventListener('touchstart',()=>{ mouse.down=true; }); document.getElementById('btnFire').addEventListener('touchend',()=>{ mouse.down=false; });
document.getElementById('btnRoll').addEventListener('touchstart',()=>{ if(player.rollCooldown===0){ player.rollTime=0.28; player.rollCooldown=2.5; player.shadow=true; if(chosenUpgrades.includes('shock')){ enemies.forEach(e=>{ if(dist(e,player)<80){ e.hp-=12; if(e.hp<=0) killEnemy(e); } }); } } });

btnStart.addEventListener('click', ()=>{ startGame(); ensureAudio(); });
btnPause.addEventListener('click', ()=>{ pauseGame(); });
btnReset.addEventListener('click', ()=>{ resetGame(); });

// upgrade choices UI update (non-blocking)
setInterval(()=>{
  document.getElementById('upgradeChoices').innerText = 'بعد از ' + Math.ceil(upgradeTimer) + 's آپگرید می‌آید.';
}, 400);

// safety: prevent accidental runaway loops
window.addEventListener('blur', ()=>{ running=false; });

// initial drawing loop for idle display
(function idleLoop(){
  render();
  requestAnimationFrame(idleLoop);
})();

// expose for debugging (optional)
window._sp = { startGame, pauseGame, resetGame, getState: ()=>({score,wave,player,chosenUpgrades}) };
